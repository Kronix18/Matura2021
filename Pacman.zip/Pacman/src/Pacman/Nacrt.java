package Pacman;

import java.awt.*;

public class Nacrt extends Rectangle {
	
	Color barva;
	Nacrt(int x, int y, int sirina, int visina, Color barva){
		this.x=x;
		this.y=y;
		this.width=sirina;
		this.height=visina;
		this.barva=barva;
	}
	public void narisi(Graphics g) {
		g.setColor(barva);
		g.fillRect(this.x, this.y, this.width, this.height);
	}
	
}
