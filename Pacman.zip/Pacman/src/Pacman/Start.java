package Pacman;

import java.awt.Dimension;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class Start extends JFrame {
	static Start pacman;
	static Dimension d = new Dimension(20,20);
	Image icon = new ImageIcon("Slike/pacright.png").getImage();
	public Start() {
        naloziGraficniVmesnik();
    }
    void naloziGraficniVmesnik() {
    	add(new Igra(d));
        setTitle("Pacman");
        setIconImage(icon);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);
        setSize((int)((16/9.0)*(d.width*27)+7),d.height*27 + 39);
        setResizable(false);
        setLocationRelativeTo(null);
        setVisible(true);
    }
    public static void main(String[] args) {
		pacman = new Start();
    }

	

}


