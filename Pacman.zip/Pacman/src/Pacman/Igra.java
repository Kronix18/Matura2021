package Pacman;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.Timer;

public class Igra extends JPanel {
	JPanel meni = new JPanel();
	short panw, panh, pacx, pacy, pacsmer =-1,pacsmert = -1, rezultat = 0, zivljenja = 3,
			sekunde, cas = 0, time2 = 0, zamik = 8, stSlike = 0, stKrogcev = 0, 
			locx, locy, locg1x, locg1y, locg2x, locg2y, locg3x, locg3y, 
			locg4x, locg4y, locg5x, locg5y;
	boolean igra, seka=false, menu;
	Dimension d1, d;
	Image slika, pacgor, pacgor1,pacgor2,pacgor3,pacgor4,pacdol,pacdol1,pacdol2,pacdol3,pacdol4,
		  paclevo,paclevo1,paclevo2,paclevo3,paclevo4,pacdesno,pacdesno1,pacdesno2,pacdesno3,pacdesno4,
		  duhSlika1, duhSlika2, duhSlika3, duhSlika4, duhSlika5;
	Font pisava, zmaga, zmaga1;
	Timer casovnik;
	int[][] polje = new int[27][27];
	Nacrt zid1, pacman, duh1, duh2, duh3, duh4, duh5;
	Igra(Dimension d2){
		d1 = d2;
		d = new Dimension(27*d1.width,27*d1.height); //dimenzija labirinta
		setSize(d);
		setLocation((int)((((16/9.0)*d.width)-d.height)/2.0), 0); //pozicija labirinta v okvirju
		//hitrosti pacmana in duhov v smereh x in y
		pacx = (short) (d1.width/20);
		pacy = (short) (d1.width/20);
		
		pisava = new Font("Helvetica", Font.BOLD, d1.height/2);
		zmaga = new Font("Stencil", Font.PLAIN, d1.height);
		zmaga1 = new Font("Georgia", Font.PLAIN, d1.height*2/3);
		setBackground(Color.black);
		
		setFocusable(true);
		//dimenzije za panelo meni
		panh = (short) d.height;
		panw = (short) (d.width/3);
		labirint();
	}
	void labirint() {
		igra = true;
		menu = false;
		int[] polje1=	{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
		int[] polje2=	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1};
		int[] polje3=	{1,0,1,1,1,1,0,1,1,1,0,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1};
		int[] polje4=	{1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1};
		int[] polje5=	{1,0,1,0,1,1,1,1,1,0,1,1,1,0,1,1,1,1,1,0,1,1,1,0,1,0,1};
		int[] polje6=	{1,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,1};
		int[] polje7=	{1,0,1,0,1,0,1,1,1,1,1,1,0,1,0,1,1,1,1,0,1,0,1,0,1,0,1};
		int[] polje8=	{1,0,1,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,1};
		int[] polje9=	{1,0,0,0,1,0,1,0,1,1,1,1,1,0,1,1,0,1,1,0,1,0,1,0,1,0,1};
		int[] polje10=	{1,0,1,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,1,0,1};
		int[] polje11=	{1,0,1,0,1,0,1,0,1,0,1,1,0,0,0,1,1,0,1,0,0,0,0,0,1,0,1};
		int[] polje12=	{1,0,1,0,1,0,1,0,1,0,1,1,9,9,9,1,1,0,1,0,1,0,1,0,0,0,1};
		int[] polje13=	{1,0,1,0,1,0,1,0,0,0,1,1,9,9,9,1,1,0,0,0,1,0,1,0,1,0,1};
		int[] polje14=	{1,0,0,0,1,0,1,0,1,0,1,1,9,9,9,1,1,0,1,0,1,0,1,0,1,0,1};
		int[] polje15=	{1,0,1,0,1,0,0,0,1,0,1,1,1,1,1,1,1,0,1,0,0,0,1,0,1,0,1};
		int[] polje16=	{1,0,1,0,1,0,1,0,1,0,1,0,0,0,0,0,1,0,1,0,1,0,1,0,0,0,1};
		int[] polje17=	{1,0,1,0,0,0,1,0,0,0,1,0,1,1,0,1,1,0,1,0,1,0,1,0,1,0,1};
		int[] polje18=	{1,0,1,0,1,0,1,0,1,0,0,0,0,0,0,0,0,0,1,0,1,0,1,0,1,0,1};
		int[] polje19=	{1,0,1,0,1,0,1,0,1,1,0,1,1,1,0,1,1,1,1,0,1,0,1,0,0,0,1};
		int[] polje20=	{1,0,1,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,1,0,1};
		int[] polje21=	{1,0,0,0,1,0,1,1,1,1,1,0,1,1,0,1,1,1,0,1,1,0,0,0,1,0,1};
		int[] polje22=	{1,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,1};
		int[] polje23=	{1,0,1,0,1,1,1,1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1,0,1};
		int[] polje24=	{1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1};
		int[] polje25=	{1,0,1,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,0,1};
		int[] polje26=	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1};
		
		polje[0]= polje1;
		polje[1]= polje2;
		polje[2]= polje3;
		polje[3]= polje4;
		polje[4]= polje5;
		polje[5]= polje6;
		polje[6]= polje7;
		polje[7]= polje8;
		polje[8]= polje9;
		polje[9]= polje10;
		polje[10]= polje11;
		polje[11]= polje12;
		polje[12]= polje13;
		polje[13]= polje14;
		polje[14]= polje15;
		polje[15]= polje16;
		polje[16]= polje17;
		polje[17]= polje18;
		polje[18]= polje19;
		polje[19]= polje20;
		polje[20]= polje21;
		polje[21]= polje22;
		polje[22]= polje23;
		polje[23]= polje24;
		polje[24]= polje25;
		polje[25]= polje26;
		polje[26] = polje1;
		for (int x= 0; x<polje.length;x++)
			for (int y = 0; y<polje[x].length;y++)
				if(polje[x][y]==0)
					stKrogcev++;
		
		zacetnePozicije();
		naloziIgro();
		naloziCasovnik();
		casovnik.start();
	}
	void zacetnePozicije() {
		//Zacetna pozicija Pac-Mana
		locx=(short) (12*d1.width);
		locy=(short) (11*d1.height);
		
		//Zacetna pozicija duha 1
		locg1x = (short) (24*d1.width);
		locg1y = (short) (0*d1.height);
		
		//Zacetna pozicija duha 2
		locg2x = (short) (22*d1.width);
		locg2y = (short) (2*d1.height);
		
		//Zacetna pozicija duha 3
		locg3x = (short) (20*d1.width);
		locg3y = (short) (4*d1.height);
		
		//Zacetna pozicija duha 4
		locg4x = (short) (18*d1.width);
		locg4y = (short) (6*d1.height);
		
		//Zacetna pozicijaduha 5
		locg5x = (short) (16*d1.width);
		locg5y = (short) (8*d1.height);
		
	}
	void naloziIgro() {
		naloziSlike();
		addKeyListener(new pritisk());
	}
	void naloziSlike() {
		pacgor = new ImageIcon("Slike/pacup.png").getImage();
		pacgor1 = new ImageIcon("Slike/pacup1.png").getImage();
		pacgor2 = new ImageIcon("Slike/pacup2.png").getImage();
		pacgor3 = new ImageIcon("Slike/pacup3.png").getImage();
		pacgor4 = new ImageIcon("Slike/pac4.png").getImage();
		
		pacdol = new ImageIcon("Slike/pacdown.png").getImage();
		pacdol1 = new ImageIcon("Slike/pacdown1.png").getImage();
		pacdol2 = new ImageIcon("Slike/pacdown2.png").getImage();
		pacdol3 = new ImageIcon("Slike/pacdown3.png").getImage();
		pacdol4 = new ImageIcon("Slike/pac4.png").getImage();
		
		paclevo = new ImageIcon("Slike/pacleft.png").getImage();
		paclevo1 = new ImageIcon("Slike/pacleft1.png").getImage();
		paclevo2 = new ImageIcon("Slike/pacleft2.png").getImage();
		paclevo3 = new ImageIcon("Slike/pacleft3.png").getImage();
		paclevo4 = new ImageIcon("Slike/pac4.png").getImage();
		
		pacdesno = new ImageIcon("Slike/pacright.png").getImage();
		pacdesno1 = new ImageIcon("Slike/pacright1.png").getImage();
		pacdesno2 = new ImageIcon("Slike/pacright2.png").getImage();
		pacdesno3 = new ImageIcon("Slike/pacright3.png").getImage();
		pacdesno4 = new ImageIcon("Slike/pac4.png").getImage();
		
		duhSlika1 = new ImageIcon("Slike/duh1.png").getImage();
		duhSlika2 = new ImageIcon("Slike/duh2.png").getImage();
		duhSlika3 = new ImageIcon("Slike/duh3.png").getImage();
		duhSlika4 = new ImageIcon("Slike/duh4.png").getImage();
		duhSlika5 = new ImageIcon("Slike/duh5.png").getImage();
	}
	class pritisk extends KeyAdapter {
		@Override
		public void keyPressed(KeyEvent e) {
			if(seka) {
				if(pacsmert==2 &&locx!=0) {
					locx=(short) ((locx/d1.width)*d1.width + d1.width);
				}
				if(pacsmert==1) {
					locy=(short) ((locy/d1.height)*d1.height);
				}
				if(pacsmert==0) {
					locx= (short) ((locx/d1.width)*d1.width);
				}
				if(pacsmert==3 && locy!=0) {
					locy= (short) ((locy/d1.height)*d1.height + d1.height);
				}
			}
			int key = e.getKeyCode();
			if (igra){
				if(key == KeyEvent.VK_UP || key == 'w' || key == 'W') {
					pacsmer = 3;
				}else if(key == KeyEvent.VK_DOWN || key == 'S' || key == 's') {
					pacsmer = 1;
				}else if(key == KeyEvent.VK_LEFT || key == 'A' || key == 'a') {
					pacsmer = 2;
				}else if(key == KeyEvent.VK_RIGHT || key == 'D' || key == 'd') {
					pacsmer = 0;
				}else if(key == KeyEvent.VK_ESCAPE || key == KeyEvent.VK_PAUSE || key == 'p' || key == 'P' ) {
					
					if(casovnik.isRunning()) {
						casovnik.stop();
						menu=true;
						pavza();
					}
					else {
						casovnik.start();
						menu = false;
						pavza();
					}
				}else {}
			}
		}
	}
	void naloziCasovnik() {
		casovnik = new Timer(zamik, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cas++ ;
				long cas2 = cas/5;
				if (cas2%8 == 0) {
					stSlike = 0;
				}else if (cas2%8 == 1) {
					stSlike = 1;
				}else if (cas2%8 == 2) {
					stSlike = 2;
				}else if (cas2%8 == 3) {
					stSlike = 3;
				}else if (cas2%8 == 4) {
					stSlike = 4;
				}else if (cas2%8 == 5) {
					stSlike = 3;
				}else if (cas2%8 == 6) {
					stSlike = 2;
				}else if (cas2%8 == 7) {
					stSlike = 1;
				}
				repaint();
			}
		});
	}
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		for(int x = 0; x<polje.length;x++){	
			for (int y = 0; y<polje[x].length;y++){
				if(polje[y][x]==1){
					zid1 = new Nacrt(d1.width*x, d1.height*y, d1.width, d1.height, Color.BLUE);
					zid1.narisi(g);
				}else if(polje[y][x]==0){
					krogci(g, x, y);	
				}	
			}
		}
		narisi(g);
	}
	void krogci(Graphics g, int x, int y) {
		Graphics2D g2= (Graphics2D)g;
		g2.setColor(Color.white);
		g2.fillOval(d1.width*x+d1.width/8*3, d1.height*y+d1.height/8*3,d1.width/4,d1.height/4);
	}
	void narisi(Graphics g) {
		Graphics2D g2 = (Graphics2D)g;
		if (igra) {
			premakniPacMana(g2);
		}
		else {
			koncaj(g2);
		}
	}
	void premakniPacMana(Graphics2D g2) {
		sekunde = (short)(cas/110);
		if(cas%220==0 && sekunde != 0) {
			rezultat--;
		}
		zid();
		zamenjajSmer();
		if (!seka) {
			switch(pacsmert) {
				case 0: {
					locx+=pacx;
				}; break;
				case 1: {
					locy+= pacy;
				}; break;
				case 2: {
					locx-=pacx;
				}; break;
				case 3: {
					locy-= pacy;
				}; break;
			}
		}
		premakniDuhove(g2);
		narisi2(g2);
		sekaDuh();
	}
	void zid() {
		if(locx<0) {
			locx=0;
		}
		if(locy<0){
			locy=0;
		}
		if(pacsmert==3)
			if(locy==0) {
				seka=true;
			}
			else if(polje[((locy)/d1.height)+1][(locx/d1.width)+1] == 1){
				seka=true;
			}else {
				seka=false;
			}
		if(pacsmert==1) {
			if(polje[(locy/d1.height)+2][(locx/d1.width)+1]==1) {
				seka = true;
			}
			else seka=false;
		}
		if(pacsmert==0) {
			if(polje[(locy/d1.height)+1][(locx/d1.width)+2]==1) {
					seka=true;
			}else
					seka=false;
			}
		if(pacsmert==2) {
			if(locx==0) {
				seka=true;
			}
			else if(polje[(locy/d1.height)+1][(locx/d1.width)+1] == 1) {
				seka=true;
			}else {
				seka=false;
			}
		}
	}
	void zamenjajSmer() {
		if(pacsmert==-1) {
			pacsmert=pacsmer;
		}
		if(Math.abs(pacsmert-pacsmer)==2) {
			pacsmert=pacsmer;
		}
		else if(locx%d1.width==0 && (pacsmert == 0 || pacsmert == 2)) {
			pacsmert = pacsmer;
		}
		else if(locy%d1.height==0 && (pacsmert == 1 || pacsmert == 3)) {
			pacsmert = pacsmer;
		}
	}
 	void premakniDuhove(Graphics2D g2) {
		//duh 1
		if(locg1x<24*d1.width && locg1y==0) {
			locg1x+=pacx;
		}else if (locg1x==24*d1.width && locg1y<24*d1.height) {
			locg1y+=pacy;
		}else if(locg1y == 24*d1.height && locg1x>0) {
			locg1x-=pacx;
		}else {
			locg1y-=pacy;
		}
		//duh 2
		if(locg2x>2*d1.width && locg2y==2*d1.height) {
			locg2x-=pacx;
		}else if (locg2x==2*d1.width && locg2y<22*d1.height) {
			locg2y+=pacy;
		}else if(locg2y == 22*d1.height && locg2x<22*d1.width) {
			locg2x+=pacx;
		}else {
			locg2y-=pacy;
		}
		//duh 3
		if(locg3x<20*d1.width && locg3y==4*d1.height) {
			locg3x+=pacx;
		}else if (locg3x==20*d1.width && locg3y<20*d1.height) {
			locg3y+=pacy;
		}else if(locg3y == 20*d1.height && locg3x>4*d1.width) {
			locg3x-=pacx;
		}else {
			locg3y-=pacy;
		}
		//duh 4
		if(locg4x>6*d1.width && locg4y==6*d1.height) {
			locg4x-=pacx;
		}else if (locg4x==6*d1.width && locg4y<18*d1.height) {
			locg4y+=pacy;
		}else if(locg4y == 18*d1.height && locg4x<18*d1.width) {
			locg4x+=pacx;
		}else {
			locg4y-=pacy;
		}
		//duh 5
		if(locg5x<16*d1.width && locg5y==8*d1.height) {
			locg5x+=pacx;
		}else if (locg5x==16*d1.width && locg5y<16*d1.height) {
			locg5y+=pacy;
		}else if(locg5y == 16*d1.height && locg5x>8*d1.width) {
			locg5x-=pacx;
		}else {
			locg5y-=pacy;
		}
	}
	void narisi2(Graphics2D g2) {
		nastaviSliko();
		pacman = new Nacrt(d1.width+locx, d1.height+locy, d1.width, d1.height, new Color(0,0,0,0));
		pacman.narisi(g2);
		duh1 = new Nacrt(d1.width+locg1x, d1.height+locg1y, d1.width, d1.height, new Color (0, 0, 0,0));
		duh1.narisi(g2);
		g2.drawImage(duhSlika1, d1.width+locg1x, d1.height+locg1y, d1.width, d1.height, this);
		duh2 = new Nacrt(d1.width+locg2x, d1.height+locg2y, d1.width, d1.height, new Color (200, 0, 0,0));
		duh2.narisi(g2);
		g2.drawImage(duhSlika2, d1.width+locg2x, d1.height+locg2y, d1.width, d1.height, this);
		duh3 = new Nacrt(d1.width+locg3x, d1.height+locg3y, d1.width, d1.height, new Color (140, 0, 0,0));
		duh3.narisi(g2);
		g2.drawImage(duhSlika3, d1.width+locg3x, d1.height+locg3y, d1.width, d1.height, this);
		duh4 = new Nacrt(d1.width+locg4x, d1.height+locg4y, d1.width, d1.height, new Color (130, 0, 0,0));
		duh4.narisi(g2);
		g2.drawImage(duhSlika4, d1.width+locg4x, d1.height+locg4y, d1.width, d1.height, this);
		duh5 = new Nacrt(d1.width+locg5x, d1.height+locg5y, d1.width, d1.height, new Color (120, 0, 0, 0));
		duh5.narisi(g2);
		g2.drawImage(duhSlika5, d1.width+locg5x, d1.height+locg5y, d1.width, d1.height, this);
		g2.drawImage(slika,d1.width+locx  ,d1.height+locy, d1.width, d1.height, this);
		narisiZivljenja(g2);
		narisiRezultat(g2);
		poberiKrogec();
	}
	void nastaviSliko() {
		switch(pacsmert) {
		case 0:{
			switch(stSlike) {
				case 0: slika = pacdesno; break;
				case 1: slika = pacdesno1; break;
				case 2: slika = pacdesno2; break;
				case 3: slika = pacdesno3; break;
				case 4: slika = pacdesno4; break;
				}
			};break;
		case 2:{
			switch(stSlike) {
				case 0: slika = paclevo; break;
				case 1: slika = paclevo1; break;
				case 2: slika = paclevo2; break;
				case 3: slika = paclevo3; break;
				case 4: slika = paclevo4; break;
				}
			};break;
		case 1:{
			switch(stSlike) {
				case 0: slika = pacdol; break;
				case 1: slika = pacdol1; break;
				case 2: slika = pacdol2; break;
				case 3: slika = pacdol3; break;
				case 4: slika = pacdol4; break;
				}
			};break;
		case 3:{
			switch(stSlike) {
				case 0: slika = pacgor; break;
				case 1: slika = pacgor1; break;
				case 2: slika = pacgor2; break;
				case 3: slika = pacgor3; break;
				case 4: slika = pacgor4; break;
				}
			};break;
		default: slika = pacdesno; break;
		}
		
	}
	void narisiZivljenja(Graphics2D g2) {
		for(int i = 0; i< zivljenja; i++) {
			g2.drawImage(pacdesno, d1.width*i + d1.width/4, d.height-d1.height, d1.width, d1.height, this);
		}
		
	}
	void narisiRezultat(Graphics2D g2) {
		String cas = "Time: " + Integer.toString(sekunde);
		String tocke ="Score: " + Integer.toString(rezultat);
		FontMetrics matrika = g2.getFontMetrics(pisava);
		g2.setFont(pisava);
		g2.setColor(Color.yellow);
		g2.drawString(cas, (d1.width/2), d1.height/6*4);
		g2.drawString(tocke, d.width-matrika.stringWidth(tocke)-d1.width/2,d1.height/6*4 );
	}
	void poberiKrogec() {
		if (stKrogcev == 0 || zivljenja == 0) {
			igra = false; //konca igro, ko ni vec krogcev ali ti zmanjka zivljenj
		}
		
		//Odsek za ugotavljanje, ce Pac-Man pobere krogec
		if(pacsmert == 0 || pacsmert == 1)	
			if(polje[(locy+d1.height)/d1.height][(locx+d1.width)/d1.width] == 0){
				polje[(locy+d1.height)/d1.height][(locx+d1.width)/d1.width] = 9;
				rezultat+=5;
				stKrogcev--;
			}
		if(pacsmert == 2)	
			if(polje[(locy+d1.height)/d1.height][(locx+d1.width+(d1.width/2))/d1.width] == 0){
				polje[(locy+d1.height)/d1.height][(locx+d1.width+(d1.width/2))/d1.width] = 9;
				rezultat+=5;
				stKrogcev--;
			}
		if(pacsmert == 3)	
			if(polje[(locy+d1.height+(d1.height/2))/d1.height][(locx+d1.width)/d1.width] == 0){
				polje[(locy+d1.height+(d1.height/2))/d1.height][(locx+d1.width)/d1.width] = 9;
				rezultat+=5;
				stKrogcev--;
			}
		

	}
	void sekaDuh() {
		if(pacman.intersects(duh1) || pacman.intersects(duh2) || pacman.intersects(duh3) || pacman.intersects(duh4) || pacman.intersects(duh5) ) {
			zivljenja--;
			rezultat-=100;
			locx = (short) (12*d1.width);
			locy = (short) (11*d1.height);
			pacsmert=-1;
			pacsmer=-1;
			repaint();
		}
		if(rezultat<0)
			rezultat=0;
	}
	void koncaj(Graphics2D g2) {
		casovnik.stop();
		if (stKrogcev==0)
			zmaga1(g2);
		else if(zivljenja == 0) 
			izgubi(g2);
	}
	void zmaga1(Graphics g2){
		FontMetrics matrika = g2.getFontMetrics(zmaga);
		g2.setFont(zmaga);
		g2.setColor(new Color(0f,0f,0f,0.5f));
		g2.fillRect(0,0, d.width, d.height);
		g2.setColor(new Color(0f,0f,0f,0.8f));
		g2.fillRect(10*d1.width, 10*d1.height, 7*d1.width, 7*d1.height);
		g2.setColor(Color.green);
		String s1 = "Victory!";
		String s2 = "Score: " + Integer.toString(rezultat);
		String s3 = "Time: " + Integer.toString(sekunde);
		g2.drawString(s1,(d.width-matrika.stringWidth(s1))/2, 12*d1.height);
		g2.setFont(zmaga1);
		matrika = g2.getFontMetrics(zmaga1);
		g2.setColor(Color.red);
		g2.drawString(s2 , (d.width-matrika.stringWidth(s2))/2, 14*d1.height);
		g2.drawString(s3, (d.width-matrika.stringWidth(s3))/2, 15*d1.width);
		
		final Color c3 = new Color(225, 0, 0);
		final Color c4 = new Color(150,0,0);
		final JButton zapustiIgro = new JButton();
		zapustiIgro.setFont(new Font("Helvetica", Font.ITALIC, d1.height/2));
		zapustiIgro.setForeground(Color.black);
		zapustiIgro.setText("Quit");
		zapustiIgro.setBackground(c3);
		zapustiIgro.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
				
			}
		});
		zapustiIgro.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				zapustiIgro.setBackground(c3);
				
			}
			public void mouseExited(MouseEvent e) {
				zapustiIgro.setBackground(c4);
			}
		
		});
		Dimension d2 = new Dimension (d1.width*3, d1.height*2);
		zapustiIgro.setSize(d2);
		zapustiIgro.setLocation(d1.width*14, d1.height*16);
		zapustiIgro.setVisible(true);
		add(zapustiIgro);
		
		final Color c1 = new Color(0, 0, 225);
		final Color c2 = new Color(0,0,150);
		final JButton ponoviIgro = new JButton();
		ponoviIgro.setFont(new Font("Helvetica", Font.ITALIC, d1.height/2));
		ponoviIgro.setForeground(Color.white);
		ponoviIgro.setText("Replay Game");
		ponoviIgro.setBackground(c2);
		ponoviIgro.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				ponovno();
			}
		});
		ponoviIgro.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				ponoviIgro.setBackground(c1);
				
			}
			public void mouseExited(MouseEvent e) {
				ponoviIgro.setBackground(c2);
			}
		});
		
		Dimension g1 = new Dimension (d1.width*4, d1.height*2);
		ponoviIgro.setSize(g1);
		ponoviIgro.setLocation(d1.width*10, d1.height*16);
		ponoviIgro.setVisible(true);
		add(ponoviIgro);
	}
	void izgubi(Graphics2D g2) {
		FontMetrics matrika = g2.getFontMetrics(zmaga);
		g2.setFont(zmaga);
		g2.setColor(new Color(0f,0f,0f,0.5f));
		g2.fillRect(0,0, d.width, d.height);
		g2.setColor(new Color(0f,0f,0f,0.8f));
		g2.fillRect(10*d1.width, 10*d1.height, 7*d1.width, 7*d1.height);
		g2.setColor(Color.red);
		String s1 = "Defeat.";
		String s2 = "Score: " + Integer.toString(rezultat);
		String s3 = "Time: " + Integer.toString(sekunde);
		g2.drawString(s1,(d.width-matrika.stringWidth(s1))/2, 12*d1.height);
		g2.setFont(zmaga1);
		matrika = g2.getFontMetrics(zmaga1);
		g2.setColor(Color.red);
		g2.drawString(s2 , (d.width-matrika.stringWidth(s2))/2, 14*d1.height);
		g2.drawString(s3, (d.width-matrika.stringWidth(s3))/2, 15*d1.width);
		final Color c3 = new Color(225, 0, 0);
		final Color c4 = new Color(150,0,0);
		final JButton zapustiIgro = new JButton();
		zapustiIgro.setFont(new Font("Helvetica", Font.ITALIC, d1.height/2));
		zapustiIgro.setForeground(Color.black);
		zapustiIgro.setText("Quit");
		zapustiIgro.setBackground(c3);
		zapustiIgro.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		zapustiIgro.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				zapustiIgro.setBackground(c3);
				
			}
			public void mouseExited(MouseEvent e) {
				zapustiIgro.setBackground(c4);
			}
		
		});
		Dimension d2 = new Dimension (d1.width*3, d1.height*2);
		zapustiIgro.setSize(d2);
		zapustiIgro.setLocation(d1.width*14, d1.height*16);
		zapustiIgro.setVisible(true);
		add(zapustiIgro);
		
		final Color c1 = new Color(0, 0, 225);
		final Color c2 = new Color(0,0,150);
		final JButton ponoviIgro = new JButton();
		ponoviIgro.setFont(new Font("Helvetica", Font.ITALIC, d1.height/2));
		ponoviIgro.setForeground(Color.white);
		ponoviIgro.setText("Replay Game");
		ponoviIgro.setBackground(c2);
		ponoviIgro.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				ponovno();
			}
		});
		ponoviIgro.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				ponoviIgro.setBackground(c1);
				
			}
			public void mouseExited(MouseEvent e) {
				ponoviIgro.setBackground(c2);
			}
		});
		
		Dimension g1 = new Dimension (d1.width*4, d1.height*2);
		ponoviIgro.setSize(g1);
		ponoviIgro.setLocation(d1.width*10, d1.height*16);
		ponoviIgro.setVisible(true);
		add(ponoviIgro);
		
	}
	void ponovno(){
		Start.pacman.dispose();
		Start.main(null);
	}
	void pavza() {
		if(menu) {
			meni.setBackground(new Color(0f, 0f, 1f, 0.4f));
			meni.setSize(panw, panh);	
			repaint();
			add(meni);
			pavza1();
		}else {
			repaint();
			remove(meni);
		}
		
	}
	void pavza1() {
		Dimension d2 = new Dimension(panw-2*d1.width, d1.height*2);
		final JButton zapustiIgro = new JButton();
		zapustiIgro.setFont(new Font("Helvetica", Font.ITALIC, d1.height/2));
		zapustiIgro.setForeground(Color.black);
		zapustiIgro.setText("Quit");
		zapustiIgro.setBackground(Color.CYAN);
		zapustiIgro.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
				
			}
		});
		zapustiIgro.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				zapustiIgro.setBackground(Color.CYAN);
				
			}
			public void mouseExited(MouseEvent e) {
				zapustiIgro.setBackground(new Color(0, 200, 200));
			}
		
		});
		zapustiIgro.setSize(d2);
		zapustiIgro.setLocation(d1.width, d.height-3*d1.height);
		zapustiIgro.setVisible(true);
		meni.add(zapustiIgro);
		
		final JButton ponoviIgro = new JButton();
		ponoviIgro.setFont(new Font("Helvetica", Font.ITALIC, d1.height/2));
		ponoviIgro.setForeground(Color.black);
		ponoviIgro.setText("Restart");
		ponoviIgro.setBackground(Color.CYAN);
		ponoviIgro.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				ponovno();
				
			}
		});
		ponoviIgro.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				ponoviIgro.setBackground(Color.CYAN);
				
			}
			public void mouseExited(MouseEvent e) {
				ponoviIgro.setBackground(new Color(0, 200, 200));
			}
		
		});
		ponoviIgro.setSize(d2);
		ponoviIgro.setLocation(d1.width, d.height-6*d1.height);
		ponoviIgro.setVisible(true);
		meni.add(ponoviIgro);
		
		final JButton nadaljujIgro = new JButton();
		nadaljujIgro.setFont(new Font("Helvetica", Font.ITALIC, d1.height/2));
		nadaljujIgro.setForeground(Color.black);
		nadaljujIgro.setText("Continue");
		nadaljujIgro.setBackground(Color.CYAN);
		nadaljujIgro.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				menu=false;
				casovnik.start();
				pavza();
			}
		});
		nadaljujIgro.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				nadaljujIgro.setBackground(Color.CYAN);
				
			}
			public void mouseExited(MouseEvent e) {
				nadaljujIgro.setBackground(new Color(0, 200, 200));
			}
		
		});
		nadaljujIgro.setSize(d2);
		nadaljujIgro.setLocation(d1.width, d.height-9*d1.height);
		nadaljujIgro.setVisible(true);
		meni.add(nadaljujIgro);
		
	}
}
